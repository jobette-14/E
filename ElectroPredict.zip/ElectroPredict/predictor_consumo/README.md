# Predictor de Consumo Eléctrico

## ¿Qué es este proyecto?

**Predictor de Consumo Eléctrico** es una aplicación de escritorio en Python que utiliza **regresión lineal múltiple** para aprender a partir de datos históricos y predecir el consumo eléctrico esperado. El proyecto está diseñado para fines educativos y demuestra cómo los modelos de Machine Learning pueden utilizarse para hacer predicciones basadas en variables múltiples.

## ¿Qué problema resuelve?

Este proyecto ayuda a entender cómo variables como la temperatura, la cantidad de personas en un hogar, las horas de uso de equipos eléctricos y el consumo del día anterior pueden influir en el consumo eléctrico total. Es útil para:
- Estimaciones rápidas de consumo eléctrico
- Aprender los fundamentos de la regresión lineal múltiple
- Visualizar cómo los modelos de Machine Learning encuentran patrones en los datos

## ¿Qué es la Regresión Lineal Múltiple?

La regresión lineal múltiple es un método de Machine Learning que modela la relación entre dos o más variables independientes (features) y una variable dependiente (target) asumiendo una relación lineal. La ecuación general es:

**Consumo = b0 + b1(temperatura) + b2(personas) + b3(horas de uso) + b4(consumo anterior)**

Donde:
- **b0** es el intercepto (consumo base cuando todas las variables son 0)
- **b1, b2, b3, b4** son los coeficientes que Weight cada variable
- La idea es encontrar los valores óptimos de estos coeficientes que mejor se ajusten a los datos históricos

## ¿Qué es el Machine Learning?

El **Machine Learning** (Aprendizaje Automático) es un campo de la inteligencia artificial que se enfoca en crear algoritmos que permitan a las computadoras aprender patrones de datos y tomar decisiones o predicciones basadas en esos datos, sin estar explícitamente programadas para cada tarea específica. En este proyecto utilizamos **aprendizaje supervisado** con un modelo de regresión.

## ¿Qué datos utiliza?

El modelo utiliza las siguientes variables de entrada:

| Variable | Descripción | Tipo |
|----------|-------------|------|
| Temperatura (°C) | Temperatura ambiental | Numérica |
| Personas | Cantidad de personas en el hogar | Numérica |
| Horas de uso | Horas que estuvieron encendidos equipos eléctricos | Numérica |
| Consumo anterior | Consumo eléctrico del día anterior en kWh | Numérica |

La variable objetivo que el modelo predice es:
- **Consumo eléctrico esperado en kWh** (numérica)

## ¿Cómo se entrena el modelo?

El proceso de entrenamiento sigue estos pasos:

1. **Cargar datos**: Se cargan los datos históricos desde un archivo CSV
2. **Preparar datos**: Se separan las variables independientes (X) de la variable objetivo (y)
3. **Dividir datos**: Se dividen los datos en conjunto de entrenamiento (80%) y prueba (20%)
4. **Entrenar modelo**: Se utiliza `LinearRegression` de scikit-learn para encontrar los mejores coeficientes
5. **Evaluar**: Se calculan métricas (R², MAE, RMSE) usando los datos de prueba
6. **Predecir**: El modelo puede predecir consumo para nuevos datos de entrada

## ¿Cómo se realiza una predicción?

Para predecir el consumo eléctrico:

1. Asegúrese de que el modelo esté entrenado (haga clic en "Entrenar Modelo")
2. Ingrese los valores en los campos de la interfaz:
   - Temperatura en °C
   - Cantidad de personas
   - Horas de uso de equipos
   - Consumo del día anterior en kWh
3. Haga clic en "Predecir consumo"
4. El resultado aparecerá como "Consumo estimado: XX.XX kWh"

## Métricas de Evaluación

Después de entrenar el modelo, se muestran estas métricas:

### R² (Coeficiente de Determinación)
- **Significado**: Indica qué tan bien el modelo explica la variación de los datos
- **Interpretación**: Un valor de 1.0 significa explicación perfecta, 0.0 significa que el modelo no explica la variación. Valores cerca de 1.0 son buenos.

### MAE (Mean Absolute Error)
- **Significado**: Muestra el error promedio de las predicciones
- **Interpretación**: Es el promedio de las diferencias absolutas entre reales y predichas. Un MAE menor indica mejores predicciones. Está en las mismas unidades que el objetivo (kWh).

### RMSE (Root Mean Squared Error)
- **Significado**: Mide el error dando mayor peso a errores grandes
- **Interpretación**: Al elevar al cuadrado los errores antes de promediar, este métrica penaliza más los errores grandes que el MAE. Es útil cuando los errores grandes son particularmente costosos o indeseables.

## ¿Cómo ejecutar el proyecto?

### 1. Instalar dependencias

Ejecute el siguiente comando en la terminal o línea de comandos:

```
pip install pandas numpy scikit-learn matplotlib
```

**Nota**: `tkinter` suele venir incluido con la instalación estándar de Python. Si no está disponible, puede instalarse con su gestor de paquetes del sistema.

### 2. Ejecutar la aplicación

Después de instalar las dependencias, ejecute:

```
python main.py
```

### 3. Usar la aplicación

- **Cargar CSV**: Cambiar los datos de ejemplo por sus propios datos
- **Entrenar Modelo**: Entrenar el modelo con los datos cargados
- **Predecir consumo**: Ingresar nuevos datos y obtener predicciones
- **Gráficas**: Visualizar comparativas y errores
- **Evaluación**: Ver las métricas R², MAE y RMSE

## Estructura del proyecto

```
predictor_consumo/
│
├── main.py          # Interfaz gráfica principal (Tkinter)
├── modelo.py        # Lógica de Machine Learning
├── graficas.py      # Generación de gráficas (matplotlib)
├── datos_consumo.csv # Datos históricos de ejemplo
├── requirements.txt # Dependencias de Python
└── README.md        # Documentación del proyecto
```

## Datos de ejemplo

El archivo `datos_consumo.csv` incluye 20 registros ficticios con situaciones realistas que cubren diferentes rangos de temperatura, número de personas, horas de uso y consumo. Estos datos son de ejemplo y pueden ser sustituidos por datos reales siguiendo el mismo formato de columnas.

Los datos incluyen situaciones como:
- Días cálidos con muchas personas y alto consumo
- Días frescos con pocas personas y bajo consumo
- Variaciones estacionales y de comportamiento

## Objetivo

## Objetivo

Explica que el objetivo principal es desarrollar una aplicación capaz de analizar datos históricos de consumo eléctrico y predecir el consumo esperado.

También incluye objetivos específicos como:

* Procesar datos históricos.
* Entrenar un modelo de regresión lineal múltiple.
* Realizar predicciones.
* Evaluar el modelo.
* Comparar consumo real y predicho.
* Visualizar los resultados mediante gráficas.

---

## Tecnologías utilizadas

| Tecnología | Uso |
| ---------- | --- |
| Python 3 | Lenguaje de programación principal |
| Pandas | Manipulación y análisis de datos |
| NumPy | Operaciones matemáticas y arrays |
| Scikit-learn | Creación y entrenamiento del modelo de regresión lineal |
| Matplotlib | Generación de gráficas y visualizaciones |
| Tkinter | Creación de la interfaz gráfica de escritorio |

---

## Historial de desarrollo

### Etapa 1 — Inicio
Creación de la estructura inicial del proyecto.

### Etapa 2 — Datos
Creación y organización del conjunto de datos históricos.

### Etapa 3 — Machine Learning
Implementación de la regresión lineal múltiple y entrenamiento del modelo.

### Etapa 4 — Evaluación
Implementación de las métricas MAE, MSE, RMSE y R².

### Etapa 5 — Interfaz
Creación de la interfaz gráfica con Tkinter.

### Etapa 6 — Visualización
Implementación de las gráficas de consumo real, consumo predicho y diferencia.

### Etapa 7 — Documentación
Creación y actualización del README.md.

### Etapa 8 — Versión final
Integración, pruebas y corrección de errores.

---

## Validaciones

El sistema debe validar los siguientes aspectos:

* **Campos vacíos**: Todos los campos de entrada deben completarse antes de realizar una predicción.
* **Valores numéricos**: Los campos deben aceptar solo valores numéricos; se mostrará un error si el usuario introduce texto donde debe ir un número.
* **Valores negativos**: Se evitarán valores negativos en campos donde no tengan sentido (ej. temperatura inferior a -50°C, personas negativas, horas de uso mayores a 24, consumo anterior negativo).
* **Archivos CSV**: Se validará que el archivo CSV cargado tenga las columnas esperadas (temperatura, personas, horas_uso, consumo_anterior, consumo_real).
* **Datos insuficientes**: Si el modelo no tiene suficientes datos para entrenar, se mostrará un mensaje de advertencia.

---

## Limitaciones

Las principales limitaciones del proyecto son:

* La precisión depende de la calidad y cantidad de datos disponibles.
* Los datos de ejemplo incluidos no representan necesariamente un consumo real.
* La regresión lineal supone una relación lineal entre las variables, lo que puede no capturar patrones complejos.
* Existen factores externos que pueden afectar el consumo eléctrico (estacionalidad, hábitos cambiados, eficiencia de equipos).
* Las predicciones son estimaciones y no valores garantizados; para resultados precisos se necesitarían datos reales y extensos.

---

## Mejoras futuras

Posibles mejoras para futuras versiones del proyecto:

* Utilizar datos reales obtenidos de medidores inteligentes o compañías eléctricas.
* Conectar el sistema con una base de datos para almacenar historiales de consumo.
* Crear predicciones diarias, semanales o mensuales basadas en patrones históricos.
* Incorporar más variables como el tipo de equipo eléctrico, hora del día, día de la semana.
* Comparar diferentes modelos de Machine Learning (árboles de decisión, redes neuronales) para encontrar la mejor aproximación.
* Crear un dashboard interactivo con múltiples visualizaciones.
* Guardar el historial de predicciones para análisis a largo plazo.
* Generar reportes mensuales o trimestrales de consumo.
* Crear alertas de consumo elevado basados en umbrales definidos.

---

## Ejemplo de funcionamiento

```text
Datos introducidos:

Temperatura: 32 °C
Personas: 6
Horas de uso: 9
Consumo anterior: 14.1 kWh

Resultado:

Consumo estimado: XX.XX kWh
```

IMPORTANTE: El resultado (`XX.XX`) depende del modelo entrenado y de los datos utilizados; no es un valor fijo.

---

## Conceptos de Machine Learning utilizados

### Machine Learning (Aprendizaje Automático)
Campo de la inteligencia artificial que se enfoca en crear algoritmos que permiten a las computadoras aprender patrones de datos y tomar decisiones o predicciones basadas en esos datos, sin estar explícitamente programadas para cada tarea específica.

### Aprendizaje supervisado
Tipo de Machine Learning donde el modelo aprende a partir de datos etiquetados (input-output). En este proyecto, utilizamos datos históricos con temperatura, personas, horas de uso y el consumo real como etiqueta.

### Regresión lineal múltiple
Método de aprendizaje supervisado que modela la relación entre múltiples variables independientes y una variable dependiente asumiendo una relación lineal. El modelo learns (aprende) los coeficientes (b0, b1, b2, b3, b4) que mejor se ajustan a los datos de entrenamiento.

### Variables independientes
Son las entradas del modelo que se utilizan para hacer la predicción. En este proyecto:
- Temperatura (°C)
- Cantidad de personas
- Horas de uso de equipos
- Consumo eléctrico del día anterior

### Variable objetivo
Es la variable que el modelo intenta predecir. En este proyecto es el **Consumo eléctrico esperado en kWh**.

### Entrenamiento
Proceso por el cual el modelo aprende los patrones y coeficientes a partir de los datos históricos. Durante el entrenamiento, el modelo ajusta sus parámetros internos para minimizar el error entre las predicciones y los valores reales.

### Datos de conjunto de prueba
Porción de los datos que no se utilizan durante el entrenamiento, sino al final para evaluar el rendimiento del modelo y calcular métricas como R², MAE y RMSE.

### Predicción
Uso del modelo entrenado para estimar el consumo eléctrico basado en nuevos datos de entrada que el usuario proporciona a través de la interfaz gráfica.

### Evaluación del modelo
Proceso de medir qué tan bien el modelo realizó sus predicciones utilizando métricas cuantitativas. En este proyecto se evalúan R², MAE y RMSE para determinar la precisión y calidad del modelo.

---

## Autor

Desarrollado por: [Nombre del estudiante]

---

## Licencia

Este proyecto puede utilizarse con fines educativos, dejando claro que la licencia puede modificarse posteriormente. El código fuente está disponible en el repositorio de GitHub del proyecto.