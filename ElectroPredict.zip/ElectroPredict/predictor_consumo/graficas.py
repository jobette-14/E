"""
graficas.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Módulo que genera visualizaciones para el predictor de consumo eléctrico.
Utiliza matplotlib para crear gráficas de línea y barras comparando
consumo real vs predicho, y mostrando el error/差异.
"""

import matplotlib.pyplot as plt
import numpy as np


def graficar_comparacion(y_test, predictions, titulo="Comparación Consumo Real vs Predicho"):
    """Genera una gráfica de línea comparando consumo real vs predicho.

    Args:
        y_test: Valores reales de consumo.
        predictions: Valores predichos por el modelo.
        titulo: Título de la gráfica.
    """
    # Ordenar por el índice para que la línea tenga sentido cronológico
    indices = range(len(y_test))

    plt.figure(figsize=(10, 6))
    plt.plot(indices, y_test, label='Consumo Real', marker='o', linestyle='-',
             color='blue', alpha=0.7)
    plt.plot(indices, predictions, label='Consumo Predicho', marker='x',
             linestyle='--', color='red', alpha=0.7)

    plt.title(titulo, fontsize=14, fontweight='bold')
    plt.xlabel('Número de registro (Día)', fontsize=12)
    plt.ylabel('Consumo eléctrico (kWh)', fontsize=12)
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()


def graficar_barras_comparacion(y_test, predictions, titulo="Comparación por Barras"):
    """Genera una gráfica de barras comparando consumo real vs predicho.

    Args:
        y_test: Valores reales de consumo.
        predictions: Valores predichos por el modelo.
        titulo: Título de la gráfica.
    """
    indices = range(len(y_test))

    plt.figure(figsize=(10, 6))
    ancho = 0.35

    # Barras para consumo real
    plt.bar([i - ancho/2 for i in indices], y_test, width=ancho,
            label='Consumo Real', color='steelblue', alpha=0.8)

    # Barras para consumo predicho
    plt_bar = plt.bar([i + ancho/2 for i in indices], predictions, width=ancho,
                      label='Consumo Predicho', color='lightcoral', alpha=0.8)

    plt.title(titulo, fontsize=14, fontweight='bold')
    plt.xlabel('Número de registro', fontsize=12)
    plt.ylabel('Consumo eléctrico (kWh)', fontsize=12)
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3, axis='y')
    plt.tight_layout()
    plt.show()


def graficar_errores(y_test, predictions, titulo="Error entre Real y Predicho"):
    """Genera una gráfica que muestra la diferencia/error entre consumo real
    y predicho.

    Args:
        y_test: Valores reales de consumo.
        predictions: Valores predichos por el modelo.
        titulo: Título de la gráfica.
    """
    # Calcular diferencias y errores absolutos
    diferencias = y_test - predictions
    error_absoluto = np.abs(diferencias)

    indices = range(len(y_test))

    plt.figure(figsize=(10, 6))

    # Gráfica de diferencias (línea)
    plt.plot(indices, diferencias, label='Diferencia (Real - Predicho)',
             color='purple', marker='o', linestyle='-')

    # Línea en cero para referencia
    plt.axhline(y=0, color='black', linestyle='-', linewidth=1, alpha=0.3)

    plt.title(titulo, fontsize=14, fontweight='bold')
    plt.xlabel('Número de registro', fontsize=12)
    plt.ylabel('Diferencia (kWh)', fontsize=12)
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()


def graficar_errores_absolutos(y_test, predictions, titulo="Error Absoluto"):
    """Genera una gráfica de barras con los errores absolutos.

    Args:
        y_test: Valores reales de consumo.
        predictions: Valores predichos por el modelo.
        titulo: Título de la gráfica.
    """
    error_absoluto = np.abs(y_test - predictions)
    indices = range(len(y_test))

    plt.figure(figsize=(10, 6))
    plt.bar(indices, error_absoluto, color='orange', alpha=0.7, edgecolor='darkorange')

    plt.title(titulo, fontsize=14, fontweight='bold')
    plt.xlabel('Número de registro', fontsize=12)
    plt.ylabel('Error absoluto (kWh)', fontsize=12)
    plt.grid(True, alpha=0.3, axis='y')
    plt.tight_layout()
    plt.show()


def graficar_todas_las_visualizaciones(y_test, predictions, nombre_archivo=None):
    """Genera todas las visualizaciones posibles en una sola figura organizada.

    Args:
        y_test: Valores reales de consumo.
        predictions: Valores predichos por el modelo.
        nombre_archivo: Si se proporciona, guarda la figura en lugar de mostrarla.
    """
    diferencias = y_test - predictions
    error_absoluto = np.abs(diferencias)
    indices = range(len(y_test))

    # Crear figura con subplots
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    fig.suptitle('Visualizaciones Completo - Predictor de Consumo Eléctrico',
                 fontsize=16, fontweight='bold')

    # Gráfica 1: Línea - Real vs Predicho
    ax1 = axes[0, 0]
    ax1.plot(indices, y_test, label='Consumo Real', marker='o', linestyle='-',
             color='blue', alpha=0.7)
    ax1.plot(indices, predictions, label='Consumo Predicho', marker='x',
             linestyle='--', color='red', alpha=0.7)
    ax1.set_title('Real vs Predicho (Línea)')
    ax1.set_xlabel('Número de registro')
    ax1.set_ylabel('Consumo (kWh)')
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # Gráfica 2: Barras - Comparación
    ax2 = axes[0, 1]
    ancho = 0.35
    ax2.bar([i - ancho/2 for i in indices], y_test, width=ancho,
            label='Consumo Real', color='steelblue', alpha=0.8)
    ax2.bar([i + ancho/2 for i in indices], predictions, width=ancho,
            label='Consumo Predicho', color='lightcoral', alpha=0.8)
    ax2.set_title('Comparación por Barras')
    ax2.set_xlabel('Número de registro')
    ax2.set_ylabel('Consumo (kWh)')
    ax2.legend()
    ax2.grid(True, alpha=0.3, axis='y')

    # Gráfica 3: Errores
    ax3 = axes[0, 2]
    ax3.plot(indices, diferencias, label='Diferencia (Real - Predicho)',
             color='purple', marker='o', linestyle='-')
    ax3.axhline(y=0, color='black', linestyle='-', linewidth=1, alpha=0.3)
    ax3.set_title('Diferencias entre Real y Predicho')
    ax3.set_xlabel('Número de registro')
    ax3.set_ylabel('Diferencia (kWh)')
    ax3.legend()
    ax3.grid(True, alpha=0.3)

    # Gráfica 4: Errores absolutos - Barras
    ax4 = axes[1, 0]
    ax4.bar(indices, error_absoluto, color='orange', alpha=0.7, edgecolor='darkorange')
    ax4.set_title('Errores Absolutos')
    ax4.set_xlabel('Número de registro')
    ax4.set_ylabel('Error absoluto (kWh)')
    ax4.grid(True, alpha=0.3, axis='y')

    # Gráfica 5: Histograma de errores
    ax5 = axes[1, 1]
    ax5.hist(diferencias, bins=10, color='green', alpha=0.7, edgecolor='darkgreen')
    ax5.set_title('Distribución de Errores')
    ax5.set_xlabel('Error (kWh)')
    ax5.set_ylabel('Frecuencia')
    ax5.grid(True, alpha=0.3)

    # Gráfica 6: Scatter plot - Real vs Predicho
    ax6 = axes[1, 2]
    ax6.scatter(y_test, predictions, color='darkblue', alpha=0.6)
    # Línea ideal (predicción perfecta)
    min_val = min(min(y_test), min(predictions))
    max_val = max(max(y_test), max(predictions))
    ax6.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2, label='Predicción Perfecta')
    ax6.set_title('Real vs Predicho (Scatter)')
    ax6.set_xlabel('Consumo Real (kWh)')
    ax6.set_ylabel('Consumo Predicho (kWh)')
    ax6.legend()
    ax6.grid(True, alpha=0.3)

    plt.tight_layout()
    if nombre_archivo:
        plt.savefig(nombre_archivo, dpi=150, bbox_inches='tight')
        print(f"[FOTO] Gráficas guardadas en: {nombre_archivo}")
    else:
        plt.show()