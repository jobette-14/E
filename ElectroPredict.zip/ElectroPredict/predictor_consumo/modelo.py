"""
modelo.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Módulo que contiene la lógica de Machine Learning para el predictor de consumo
eléctrico. Encapsula el entrenamiento, predicción y evaluación del modelo de
regresión lineal múltiple.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


class PredictorConsumo:
    """Clase que encapsula el modelo de regresión lineal múltiple para predecir
    el consumo eléctrico."""

    def __init__(self):
        self.modelo = LinearRegression()
        self.datos_entrenamiento = None
        self.datos_prueba = None
        self.predictions = None
        self.r2 = None
        self.mae = None
        self.mse = None
        self.rmse = None
        self.nombre_archivo = "datos_consumo.csv"
        self.metodos_entrenamiento = 0

    def cargar_datos(self, ruta_archivo="datos_consumo.csv"):
        """Carga los datos desde un archivo CSV.

        Args:
            ruta_archivo: Ruta del archivo CSV con los datos históricos.

        Returns:
            DataFrame con los datos cargados.
        """
        try:
            self.datos = pd.read_csv(ruta_archivo)
            print("! Datos cargados exitosamente: " + str(len(self.datos)) + " registros")
            print(f"Columnas: {list(self.datos.columns)}")
            # Mensaje importante: datos de ejemplo
            print("ADVERTENCIA: Estos son datos de ejemplo. Para datos reales, "
                  "carga un archivo CSV con las mismas columnas.")
            return self.datos
        except FileNotFoundError:
            print(f"[X] Error: No se encontró el archivo {ruta_archivo}")
            return None

    def preparar_datos(self):
        """Separa variables independientes de la variable objetivo y divide
        los datos en entrenamiento y prueba."""

        if not hasattr(self, 'datos'):
            print("[X] Error: Primero debe cargar los datos.")
            return False

        # Variables independientes (X): temperatura, personas, horas_uso, consumo_anterior
        X = self.datos[['temperatura', 'personas', 'horas_uso', 'consumo_anterior']].values

        # Variable objetivo (y): consumo_real
        y = self.datos['consumo_real'].values

        # Dividir en entrenamiento (80%) y prueba (20%)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42)

        self.X_train = X_train
        self.y_train = y_train
        self.X_test = X_test
        self.y_test = y_test

        # Guardar también los datos completos para referencia
        self.datos_entrenamiento = (X_train, y_train)
        self.datos_prueba = (X_test, y_test)

        print(f"[FOTO] Datos divididos: {len(X_train)} registros de entrenamiento, "
              f"{len(X_test)} registros de prueba")
        return True

    def entrenar_modelo(self):
        """Entrena el modelo de regresión lineal con los datos de entrenamiento."""

        if not hasattr(self, 'X_train'):
            print("[X] Error: Primero debe preparar los datos.")
            return False

        self.modelo.fit(self.X_train, self.y_train)
        print("[ROSTRO] Modelo entrenado exitosamente con regresión lineal múltiple")

        # Obtener los coeficientes del modelo
        self.coeficientes = self.modelo.coef_
        self.intercepto = self.modelo.intercept_

        print(f"📈 Coeficientes del modelo: {self.coeficientes}")
        print(f"📈 Intercepto (b0): {self.intercepto}")

        self.metodos_entrenamiento = len(self.X_train)
        return True

    def predecir(self, temperatura, personas, horas_uso, consumo_anterior):
        """Realiza una predicción de consumo eléctrico.

        Args:
            temperatura: Temperatura en °C.
            personas: Cantidad de personas.
            horas_uso: Horas de uso de equipos eléctricos.
            consumo_anterior: Consumo eléctrico del día anterior en kWh.

        Returns:
            Predicción de consumo en kWh.
        """
        if self.modelo is None:
            print("[X] Error: El modelo no ha sido entrenado.")
            return None

        # Preparar los datos de entrada para la predicción
        entrada = np.array([[temperatura, personas, horas_uso, consumo_anterior]])

        prediccion = self.modelo.predict(entrada)[0]
        return round(prediccion, 2)

    def evaluar_modelo(self):
        """Evalúa el modelo usando los datos de prueba y calcula métricas."""

        if not hasattr(self, 'X_test') or self.X_test is None:
            print("[X] Error: Primero debe entrenar el modelo.")
            return False

        # Realizar predicciones con los datos de prueba
        self.predictions = self.modelo.predict(self.X_test)

        # Calcular métricas
        self.r2 = r2_score(self.y_test, self.predictions)
        self.mae = mean_absolute_error(self.y_test, self.predictions)
        self.mse = mean_squared_error(self.y_test, self.predictions)
        self.rmse = np.sqrt(self.mse)

        print(f"\n[FOTO] Métricas de evaluación del modelo:")
        print(f"   R² (R-squared): {self.r2:.4f}")
        print(f"   MAE (Mean Absolute Error): {self.mae:.4f}")
        print(f"   MSE (Mean Squared Error): {self.mse:.4f}")
        print(f"   RMSE (Root Mean Squared Error): {self.rmse:.4f}")

        return True

    def obtener_coeficientes(self):
        """Retorna los coeficientes del modelo con nombres descriptivos."""

        if self.modelo is None:
            return None

        nombres = ['Temperatura', 'Personas', 'Horas de uso', 'Consumo anterior']
        coefs = {
            nombres[i]: round(float(self.coeficientes[i]), 4)
            for i in range(len(nombres))
        }
        coefs['Intercepto (b0)'] = round(float(self.intercepto), 4)
        return coefs


# Función de conveniencia para entrenar rápidamente con el CSV por defecto
def entrenar_desde_csv(ruta_archivo="datos_consumo.csv"):
    """Función auxiliar que carga datos, entrena y evalúa el modelo."""

    predictor = PredictorConsumo()
    datos = predictor.cargar_datos(ruta_archivo)

    if datos is None:
        return None

    if preparar_datos(predictor):
        pass  # Ya hecho dentro de la función

    if entrenar_modelo(predictor):
        pass

    if evaluar_modelo(predictor):
        pass

    return predictor