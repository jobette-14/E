"""
main.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Interfaz gráfica principal para el Predictor de Consumo Eléctrico.
Utiliza Tkinter para crear una ventana de escritorio funcional con:
- Sección de datos para predicción
- Entrenamiento del modelo
- Visualización de resultados y métricas
- Gráficas comparativas
- Validación de entradas
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pandas as pd
import numpy as np

# Importar módulos del proyecto
from modelo import PredictorConsumo
from graficas import graficar_comparacion, graficar_barras_comparacion, \
    graficar_errores, graficar_errores_absolutos, graficar_todas_las_visualizaciones


class PredictorApp:
    """Clase principal que construye y gestiona la interfaz Tkinter."""

    def __init__(self, root):
        self.root = root
        self.root.title("Predictor de Consumo Eléctrico")
        self.root.geometry("900x700")
        self.root.resizable(False, False)

        # Inicializar el predictor de ML
        self.predictor = PredictorConsumo()

        # Bandera para controlar si el modelo ha sido entrenado
        self.modelo_entrenado = False

        # Variable para rastrear el archivo CSV actual
        self.ruta_archivo_actual = "datos_consumo.csv"

        # Configurar la interfaz
        self._configurar_estilo()
        self._crear_menu()
        self._crear_contenido_principal()

        # Cargar datos iniciales
        self._cargar_datos_iniciales()

    def _configurar_estilo(self):
        """Configura el estilo de la interfaz."""
        self.style = ttk.Style()
        # Usar un tema moderno
        try:
            self.style.theme_use('clam')
        except:
            pass

        # Configurar colores de acento
        self.style.configure('Titulo.TLabel', font=('Helvetica', 16, 'bold'), foreground='#2c3e50')
        self.style.configure('Subtitulo.TLabel', font=('Helvetica', 12, 'bold'), foreground='#34495e')
        self.style.configure('Botón.Accent.TButton', foreground='white', background='#3498db')
        self.style.configure('Tarjeta.TFrame', backgroundec='#ecf0f1')

    def _crear_menu(self):
        """Crea la barra de menú superior."""
        menubar = tk.Menu(self.root)

        # Menú Archivo
        menub_archivo = tk.Menu(menubar, tearoff=0)
        menub_archivo.add_command(label="Cargar CSV", command=self._cargar_csv)
        menub_archivo.add_separator()
        menub_archivo.add_command(label="Salir", command=self.root.quit)
        menubar.add_cascade(label="Archivo", menu=menub_archivo)

        # Menú Herramientas
        menub_herramientas = tk.Menu(menubar, tearoff=0)
        menub_herramientas.add_command(label="Entrenar Modelo", command=self._entrenar_modelo)
        menub_herramientas.add_separator()
        menub_herramientas.add_command(label="Acerca de...", command=self._mostrar_acerca)
        menubar.add_cascade(label="Herramientas", menu=menub_herramientas)

        # Menú Ayuda
        menub_ayuda = tk.Menu(menubar, tearoff=0)
        menub_ayuda.add_command(label="Documentación", command=self._mostrar_documentacion)
        menubar.add_cascade(label="Ayuda", menu=menub_ayuda)

        self.root.config(menu=menubar)

    def _crear_contenido_principal(self):
        """Crea el contenido principal de la interfaz."""
        # Frame principal con padding
        self.main_frame = ttk.Frame(self.root, padding="10")
        self.main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Configurar expansión
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        self.main_frame.columnconfigure(0, weight=1)

        # Crear las diferentes secciones
        self._crear_seccion_datos_historicos()
        self._crear_seccion_entrenamiento()
        self._crear_seccion_prediccion()
        self._crear_seccion_resultado()
        self._crear_seccion_evaluacion()
        self._crear_seccion_gráficas()

    def _crear_seccion_datos_historicos(self):
        """Sección: Datos históricos."""
        frame = ttk.LabelFrame(self.main_frame, text="[FOTO] Datos Históricos", padding="5")
        frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=5)
        frame.columnconfigure(0, weight=1)

        # Información de datos
        try:
            datos = self.predictor.cargar_datos()
            if datos is not None:
                num_registros = len(datos)
                ttk.Label(frame, text=f"Registros cargados: {num_registros}").grid(
                    row=0, column=0, sticky=tk.W, pady=2)
                ttk.Label(frame, text="Columnas: temperatura, personas, horas_uso, consumo_anterior, consumo_real").grid(
                    row=1, column=0, sticky=tk.W, pady=2)
        except Exception as e:
            ttk.Label(frame, text="Error cargando datos").grid(row=0, column=0, pady=2)

        ttk.Label(frame, text="*(Datos de ejemplo incluidos, pueden reemplazarse)", \
                  foreground='red').grid(row=2, column=0, sticky=tk.W, pady=3)

    def _crear_seccion_entrenamiento(self):
        """Sección: Entrenamiento del modelo."""
        frame = ttk.LabelFrame(self.main_frame, text="[ROSTRO] Entrenamiento del Modelo", padding="5")
        frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=5)
        frame.columnconfigure(0, weight=1)

        ttk.Button(frame, text="Entrenar Modelo", command=self._entrenar_modelo).grid(
            row=0, column=0, pady=5, sticky=tk.W)

        self.label_estado_modelo = ttk.Label(frame, text="")
        self.label_estado_modelo.grid(row=1, column=0, sticky=tk.W, pady=3)

        self.label_registros_entrenamiento = ttk.Label(
            frame, text="Registros de entrenamiento: --")
        self.label_registros_entrenamiento.grid(
            row=2, column=0, sticky=tk.W, pady=3)

    def _crear_seccion_prediccion(self):
        """Sección: Datos para la predicción."""
        frame = ttk.LabelFrame(self.main_frame, text="📝 Datos para la Predicción", padding="5")
        frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=5)
        frame.columnconfigure(0, weight=1)

        # Etiquetas y campos de entrada
        labels_text = ['Temperatura (°C):', 'Cantidad de personas:', \
                       'Horas de uso de equipos:', 'Consumo día anterior (kWh):']

        self.entries = {}
        for i, texto in enumerate(labels_text):
            ttk.Label(frame, text=texto).grid(row=i, column=0, sticky=tk.W, pady=3)
            entry = ttk.Entry(frame, width=30)
            entry.grid(row=i, column=1, pady=3, padx=(5, 0))
            self.entries[texto] = entry

        ttk.Button(frame, text="Predecir consumo", command=self._hacer_prediccion).grid(
            row=4, column=0, columnspan=2, pady=10, sticky=tk.W)

        self.label_resultado = ttk.Label(frame, text="", font=('Helvetica', 12, 'bold'),
                                         foreground='#2c3e50')
        self.label_resultado.grid(row=5, column=0, columnspan=2, sticky=tk.W)

    def _crear_seccion_resultado(self):
        """Sección: Resultado de la predicción."""
        # Esta sección se actualiza dinámicamente, pero dejamos un espacio reservado
        pass

    def _crear_seccion_evaluacion(self):
        """Sección: Evaluación del modelo."""
        frame = ttk.LabelFrame(self.main_frame, text="📈 Evaluación del Modelo", padding="5")
        frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=5)
        frame.columnconfigure(0, weight=1)

        # Frame para las métricas
        metrics_frame = ttk.Frame(frame)
        metrics_frame.grid(row=0, column=0, sticky=(tk.W, tk.E))

        # Etiquetas para las métricas
        self.label_r2 = ttk.Label(metrics_frame, text="R²: --", font=('Helvetica', 10))
        self.label_r2.grid(row=0, column=0, sticky=tk.W, padx=(0, 10))

        self.label_mae = ttk.Label(metrics_frame, text="MAE: --", font=('Helvetica', 10))
        self.label_mae.grid(row=0, column=1, sticky=tk.W, padx=(0, 10))

        self.label_rmse = ttk.Label(metrics_frame, text="RMSE: --", font=('Helvetica', 10))
        self.label_rmse.grid(row=0, column=2, sticky=tk.W, padx=(0, 10))

        # Descripciones breves
        ttk.Label(frame, text="*R²: indica qué tan bien el modelo explica la variación de los datos.", \
                  font=('Helvetica', 8), foreground='gray').grid(row=1, column=0, sticky=tk.W, pady=2)
        ttk.Label(frame, text="*MAE: muestra el error promedio de las predicciones.", \
                  font=('Helvetica', 8), foreground='gray').grid(row=2, column=0, sticky=tk.W, pady=1)
        ttk.Label(frame, text="*RMSE: mide el error dando mayor peso a errores grandes.", \
                  font=('Helvetica', 8), foreground='gray').grid(row=3, column=0, sticky=tk.W, pady=1)

    def _crear_seccion_gráficas(self):
        """Sección: Gráficas."""
        frame = ttk.LabelFrame(self.main_frame, text="[FOTO] Gráficas", padding="5")
        frame.grid(row=4, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)

        # Botones para tipos de gráficas
        btn_frame = ttk.Frame(frame)
        btn_frame.grid(row=0, column=0, sticky=tk.W, pady=3)

        ttk.Button(btn_frame, text="Gráfica Línea", \
                   command=lambda: self._mostrar_grafica_lineas()).grid(row=0, column=0, padx=3)
        ttk.Button(btn_frame, text="Gráfica Barras", \
                   command=lambda: self._mostrar_grafica_barras).grid(row=0, column=1, padx=3)
        ttk.Button(btn_frame, text="Todas las Visualizaciones", \
                   command=lambda: self._mostrar_todas_las_visualizaciones).grid(row=0, column=2, padx=3)

        # Área para mostrar la gráfica (usaremos un Label como placeholder)
        self.label_grafica = ttk.Label(frame, text="Las gráficas aparecerán aquí \n \
                                        después del entrenamiento y predicción",
                                        foreground='gray')
        self.label_grafica.grid(row=1, column=0, pady=10, sticky=(tk.W, tk.E))

    # === Métodos de acción ===

    def _cargar_datos_iniciales(self):
        """Carga los datos iniciales al iniciar la aplicación."""
        self.predictor.cargar_datos(self.ruta_archivo_actual)
        try:
            datos = self.predictor.datos
            if datos is not None:
                num_registros = len(datos)
                # Actualizar la sección de datos históricos
                for widget in self.main_frame.winfo_children():
                    if hasattr(widget, 'cget') and 'Datos Históricos' in widget.cget('text'):
                        for w in widget.winfo_children():
                            if isinstance(w, ttk.Label) and 'Registros cargados' in w.cget('text'):
                                w.config(text=f"Registros cargados: {num_registros}")
        except:
            pass

    def _cargar_csv(self):
        """Permite al usuario cargar un archivo CSV personalizado."""
        ruta = filedialog.askopenfilename(
            title="Seleccionar archivo CSV",
            filetypes=[("Archivos CSV", "*.csv"), ("Todos los archivos", "*.*")]
        )
        if ruta:
            self.ruta_archivo_actual = ruta
            self.predictor.cargar_datos(ruta)

            # Mostrar información básica
            messagebox.showinfo("CSV Cargado", \
                f"Archivo cargado exitosamente:\n{ruta}\n\n" \
                f"Registros: {len(self.predictor.datos)}")

            # Reiniciar estado del modelo
            self.modelo_entrenado = False
            self.label_estado_modelo.config(text="Modelo sin entrenar")
            self.label_r2.config(text="R²: --")
            self.label_mae.config(text="MAE: --")
            self.label_rmse.config(text="RMSE: --")
            self.label_resultado.config(text="")

            # Limpiar campos de entrada
            for entry in self.entries.values():
                entry.delete(0, tk.END)

            print("! Nuevo CSV cargado: " + ruta)

    def _entrenar_modelo(self):
        """Entrena el modelo con los datos cargados."""
        if not hasattr(self.predictor, 'datos') or self.predictor.datos is None:
            messagebox.showerror("Error", "No hay datos cargados. \
                                  Carga un archivo CSV primero.")
            return

        # Preparar y entrenar
        success = self.predictor.preparar_datos()
        if not success:
            return

        success = self.predictor.entrenar_modelo()
        if success:
            self.modelo_entrenado = True
            self.label_estado_modelo.config(text="Modelo entrenado correctamente")

            # Mostrar número de registros de entrenamiento
            num_registros = self.predictor.metodos_entrenamiento
            self.label_registros_entrenamiento.config(
                text=f"Registros de entrenamiento: {num_registros}")

            # Evaluar el modelo
            self.predictor.evaluar_modelo()

            # Actualizar interfaz con métricas
            self.label_r2.config(text=f"R²: {self.predictor.r2:.4f}")
            self.label_mae.config(text=f"MAE: {self.predictor.mae:.4f}")
            self.label_rmse.config(text=f"RMSE: {self.predictor.rmse:.4f}")

            # Mostrar mensaje de éxito
            messagebox.showinfo("Éxito", \
                f"Modelo entrenado exitosamente!\n\n" \
                f"• R²: {self.predictor.r2:.4f}\n" \
                f"• MAE: {self.predictor.mae:.4f}\n" \
                f"• RMSE: {self.predictor.rmse:.4f}\n\n" \
                f"Se usaron {self.predictor.metodos_entrenamiento} registros para entrenar.")

    def _hacer_prediccion(self):
        """Realiza una predicción con los datos ingresados por el usuario."""
        if not self.modelo_entrenado:
            messagebox.showerror("Error", "El modelo no ha sido entrenado. \
                                  Primero haga clic en 'Entrenar Modelo'.")
            return

        # Obtener valores de los campos de entrada
        try:
            temperatura = float(self.entries['Temperatura (°C):'].get())
            personas = float(self.entries['Cantidad de personas:'].get())
            horas_uso = float(self.entries['Horas de uso de equipos:'].get())
            consumo_anterior = float(self.entries['Consumo día anterior (kWh):'].get())

            # Validación: evitar valores negativos donde no tengan sentido
            if temperatura < -50 or temperatura > 100:
                messagebox.showerror("Valor inválido", \
                    "La temperatura debe estar entre -50°C y 100°C.")
                return

            if personas < 0 or personas > 50:
                messagebox.showerror("Valor inválido", \
                    "La cantidad de personas debe ser entre 0 y 50.")
                return

            if horas_uso < 0 or horas_uso > 24:
                messagebox.showerror("Valor inválido", \
                    "Las horas de uso deben estar entre 0 y 24.")
                return

            if consumo_anterior < 0:
                messagebox.showerror("Valor inválido", \
                    "El consumo del día anterior no puede ser negativo.")
                return

            # Realizar predicción
            prediccion = self.predictor.predecir(temperatura, personas, \
                                                 horas_uso, consumo_anterior)

            if prediccion is not None:
                # Mostrar resultado
                self.label_resultado.config(text=f"Consumo estimado: {prediccion} kWh")

                # Mostrar información adicional
                mensaje = f"Predicción completada\n\n"
                mensaje += f"Datos de entrada:\n"
                mensaje += f"  • Temperatura: {temperatura}°C\n"
                mensaje += f"  • Personas: {personas}\n"
                mensaje += f"  • Horas de uso: {horas_uso}h\n"
                mensaje += f"  • Consumo anterior: {consumo_anterior}kWh\n\n"
                mensaje += f"Resultado:\n"
                mensaje += f"  • Consumo estimado: {prediccion} kWh"
                messagebox.showinfo("Resultado de la Predicción", mensaje)

        except ValueError:
            messagebox.showerror("Error de entrada", \
                "Por favor, introduzca valores numéricos válidos en todos los campos.")
        except Exception as e:
            messagebox.showerror("Error inesperado", \
                f"Ocurrió un error al realizar la predicción:\n{str(e)}")

    def _mostrar_grafica_lineas(self):
        """Muestra la gráfica de líneas comparando real vs predicho."""
        if not self.modelo_entrenado or self.predictor.predictions is None:
            messagebox.showinfo("Información", \
                "Primero debe entrenar el modelo y realizar al menos una predicción.")
            return

        graficar_comparacion(self.predictor.y_test, self.predictor.predictions,
                            "Comparación: Consumo Real vs Predicho (Línea)")

    def _mostrar_grafica_barras(self):
        """Muestra la gráfica de barras comparando real vs predicho."""
        if not self.modelo_entrenado or self.predictor.predictions is None:
            messagebox.showinfo("Información", \
                "Primero debe entrenar el modelo y realizar al menos una predicción.")
            return

        graficar_barras_comparacion(self.predictor.y_test, self.predictor.predictions,
                                   "Comparación: Consumo Real vs Predicho (Barras)")

    def _mostrar_todas_las_visualizaciones(self):
        """Muestra todas las visualizaciones posibles."""
        if not self.modelo_entrenado or self.predictor.predictions is None:
            messagebox.showinfo("Información", \
                "Primero debe entrenar el modelo y realizar al menos una predicción.")
            return

        graficar_todas_las_visualizaciones(self.predictor.y_test, \
                                          self.predictor.predictions,
                                          nombre_archivo=None)

    def _mostrar_acerca(self):
        """Muestra la información sobre la aplicación."""
        mensaje = """Predictor de Consumo Eléctrico
Versión 1.0

Una aplicación de escritorio Python que utiliza 
regresión lineal múltiple para predecir el consumo 
eléctrico basado en datos históricos.

Desarrollado para proyecto escolar de Machine Learning.
"""
        messagebox.showinfo("Acerca de...", mensaje)

    def _mostrar_documentacion(self):
        """Muestra un resumen de documentación."""
        mensaje = """Documentación Rápida:

1. Datos: El modelo usa temperatura, personas, horas de uso y consumo anterior
2. Entrenamiento: Los primeros registros se usan para entrenar el modelo
3. Predicción: Ingrese nuevos datos y haga clic en "Predecir consumo"
4. Evaluación: Ve las métricas R², MAE, RMSE después de entrenar
5. Gráficas: Explore diferentes tipos de visualizaciones"""

        messagebox.showinfo("Documentación", mensaje)


def main():
    """Punto de entrada principal de la aplicación."""
    root = tk.Tk()
    app = PredictorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()